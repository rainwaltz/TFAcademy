'use strict';

module.exports = {
  series: require('./lib/series'),
  parallel: require('./lib/parallel'),
  settleSeries: require('./lib/settleSeries'),
  settleParallel: require('./lib/settleParallel'),
};
